<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class QListTable extends \WP_List_Table {

    protected $page;

    public function __construct($page, $args = []) {
        $this->page = $page;

        $args = wp_parse_args($args, [
            'singular' => 'q-email-logger',
            'plural'   => 'q-email-logs',
            'ajax'     => false,
        ]);

        parent::__construct($args);
    }

    /**
     * Define the columns.
     */
    public function get_columns() {
        return [
            'cb'          => '<input type="checkbox" />',
            'id'          => __('ID', 'q-email-logger'),
            'result'      => '',
            'sent_date'   => __('Date Sent', 'q-email-logger'),
            'subject'     => __('Subject', 'q-email-logger'),
            'to_email'    => __('Recipient(s)', 'q-email-logger'),
            'attachments' => __('Attachments', 'q-email-logger'),
        ];
    }

    /**
     * Define sortable columns.
     */
    protected function get_sortable_columns() {
        return [
            'sent_date' => ['sent_date', true],
            'to_email'  => ['to_email', false],
            'subject'   => ['subject', false],
        ];
    }

    /**
     * Render the checkbox column.
     */
    protected function column_cb($item) {
        return sprintf(
            '<input type="checkbox" name="log[]" value="%s" />',
            $item->id
        );
    }

    /**
     * Render the sent date column with row actions.
     */
    protected function column_id($item) {
        return esc_html($item->id);
    }

    /**
     * Render the sent date column with row actions.
     */
    protected function column_sent_date($item) {
        $email_date = mysql2date(
            sprintf(
                __('%1$s %2$s', 'q-email-logger'),
                get_option('date_format', 'F j, Y'),
                QHelper::get_display_format_for_log_time()
            ),
            $item->sent_date
        );

        $actions = [];

        $content_ajax_url = add_query_arg([
            'action' => 'q-el-view-message',
            'log_id' => $item->id,
        ], admin_url('admin-ajax.php'));

        $actions['view-content'] = sprintf(
            '<a href="#" data-url="%1$s" class="q-el-view-modal" title="%2$s">%3$s</a>',
            esc_url($content_ajax_url),
            esc_attr__('Email Content', 'q-email-logger'),
            __('View Email', 'q-email-logger')
        );

        $delete_url = add_query_arg([
            'page'   => 'q-email-logger',
            'action' => 'delete',
            'log'    => $item->id,
        ], admin_url('admin.php'));
        $delete_url = wp_nonce_url($delete_url, 'q_el_delete_log_' . $item->id);

        $actions['delete'] = sprintf(
            '<a href="%s" onclick="return confirm(\'%s\')">%s</a>',
            esc_url($delete_url),
            esc_attr__('Are you sure you want to delete this log entry?', 'q-email-logger'),
            __('Delete', 'q-email-logger')
        );

        return sprintf(
            '%1$s%2$s',
            esc_html($email_date),
            $this->row_actions($actions)
        );
    }

    /**
     * Render status result column.
     */
    protected function column_result($item) {
        if (is_null($item->result)) {
            return '';
        }

        if ($item->result) {
            return '<span class="dashicons dashicons-saved" style="color: #46b450; font-size: 22px;"></span>';
        } else {
            $icon = '<span class="dashicons dashicons-warning" style="color: #dc3232; font-size: 22px;"></span>';
            if (!empty($item->error_message)) {
                return sprintf(
                    '<span class="q-el-help" title="%2$s" style="cursor:help;">%1$s</span>',
                    $icon,
                    esc_attr($item->error_message)
                );
            }
            return $icon;
        }
    }

    /**
     * Render basic columns.
     */
    protected function column_to_email($item) {
        return esc_html($item->to_email);
    }

    protected function column_subject($item) {
        return esc_html($item->subject);
    }

    /**
     * Default column rendering for custom fields (headers and attachments).
     */
    protected function column_default($item, $column_name) {
        $headers = QHelper::parse_headers($item->headers);

        switch ($column_name) {
            case 'attachments':
                if ($item->attachments === 'true' || !empty($item->attachment_name)) {
                    $icon = '<span class="dashicons dashicons-paperclip" style="font-size:16px; vertical-align:middle; margin-right:4px;"></span>';
                    return $icon . esc_html($item->attachment_name ?: __('Yes', 'q-email-logger'));
                }
                return '-';
            default:
                return '';
        }
    }

    /**
     * Define the bulk actions.
     */
    protected function get_bulk_actions() {
        return [
            'bulk-delete' => __('Delete Selected', 'q-email-logger'),
        ];
    }

    /**
     * Add extra controls or clear all buttons.
     */
    protected function extra_tablenav($which) {
        if ('top' === $which) {
            $clear_url = add_query_arg([
                'page'   => 'q-email-logger',
                'action' => 'clear-all',
            ], admin_url('admin.php'));
            $clear_url = wp_nonce_url($clear_url, 'q_el_clear_all_logs');
            ?>
            <div class="alignleft actions">
                <a href="<?php echo esc_url($clear_url); ?>" class="button q-el-clear-all-btn" onclick="return confirm('<?php echo esc_attr__('Are you sure you want to delete ALL logged emails? This action cannot be undone.', 'q-email-logger'); ?>')">
                    <?php _e('Clear Logs', 'q-email-logger'); ?>
                </a>
            </div>
            <?php
        }
    }

    /**
     * Search Box.
     */
    public function search_box($text, $input_id) {
        $input_subject_val = isset($_REQUEST['subject_filter']) ? sanitize_text_field(wp_unslash($_REQUEST['subject_filter'])) : '';
        $input_start_date  = isset($_REQUEST['start_date']) ? sanitize_text_field(wp_unslash($_REQUEST['start_date'])) : '';
        $input_end_date    = isset($_REQUEST['end_date']) ? sanitize_text_field(wp_unslash($_REQUEST['end_date'])) : '';
        $input_status      = isset($_REQUEST['status_filter']) ? sanitize_text_field(wp_unslash($_REQUEST['status_filter'])) : '';
        $input_recipients  = isset($_REQUEST['recipient_tags']) ? sanitize_text_field(wp_unslash($_REQUEST['recipient_tags'])) : '';
        ?>
        <div class="q-el-filter-bar">
            <div class="q-el-filter-group">
                <select name="status_filter" id="status_filter">
                    <option value=""><?php esc_html_e('All Statuses', 'q-email-logger'); ?></option>
                    <option value="sent" <?php selected($input_status, 'sent'); ?>><?php esc_html_e('Sent', 'q-email-logger'); ?></option>
                    <option value="failed" <?php selected($input_status, 'failed'); ?>><?php esc_html_e('Failed', 'q-email-logger'); ?></option>
                </select>
                
                <div class="q-el-tag-input-wrapper">
                    <input type="text" id="recipient_input" placeholder="<?php esc_html_e('Add Recipient...', 'q-email-logger'); ?>" autocomplete="off" />
                    <input type="hidden" name="recipient_tags" id="recipient_tags_hidden" value="<?php echo esc_attr($input_recipients); ?>" />
                    <div id="q-el-tags-container"></div>
                </div>

                <input type="text" name="subject_filter" id="subject_filter" value="<?php echo esc_attr($input_subject_val); ?>" placeholder="<?php esc_html_e('Subject...', 'q-email-logger'); ?>" />
                
                <input type="text" name="start_date" id="start_date" class="q-el-datepicker" value="<?php echo esc_attr($input_start_date); ?>" placeholder="<?php esc_html_e('Start Date', 'q-email-logger'); ?>" />
                <input type="text" name="end_date" id="end_date" class="q-el-datepicker" value="<?php echo esc_attr($input_end_date); ?>" placeholder="<?php esc_html_e('End Date', 'q-email-logger'); ?>" />

                <?php submit_button(__('Filter', 'q-email-logger'), 'button', '', false, ['id' => 'search-submit']); ?>
            </div>
        </div>
        <?php
    }

    /**
     * Empty state message.
     */
    public function no_items() {
        _e('No emails have been logged yet.', 'q-email-logger');
    }

    /**
     * Prepare table items.
     */
    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();
        $primary = 'sent_date';
        $this->_column_headers = [$columns, $hidden, $sortable, $primary];

        $current_page_no = $this->get_pagenum();
        $per_page        = $this->page->get_per_page();

        list($items, $total_items) = q_email_log()->db->fetch_log_items($_GET, $per_page, $current_page_no);

        $this->items = $items;

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil($total_items / $per_page),
        ]);
    }
}
