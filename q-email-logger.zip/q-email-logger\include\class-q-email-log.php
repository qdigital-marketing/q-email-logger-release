<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QEmailLog {

    private static $instance = null;

    /**
     * @var QDB
     */
    public $db;

    /**
     * @var QLogger
     */
    public $logger;

    /**
     * @var QAdmin
     */
    public $admin;

    /**
     * Get the singleton instance.
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->db     = new QDB();
        $this->logger = new QLogger();
        $this->admin  = new QAdmin();
    }

    /**
     * Load the plugin components.
     */
    public function load() {
        // Upgrade DB if needed
        QDB::update_table_if_needed();

        // Load logger
        $this->logger->load();

        // Load Admin UI and settings
        $this->admin->load();

        // Load translations
        load_plugin_textdomain('q-email-logger', false, dirname(plugin_basename(Q_EMAIL_LOG_FILE)) . '/languages/');
    }
}
