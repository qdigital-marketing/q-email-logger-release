<?php
/**
 * Uninstall page for Q Email Log Plugin to clean up all plugin data.
 */

// Exit if WordPress is not uninstalling the plugin.
if ( ! defined( 'ABSPATH' ) && ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit();
}

if ( is_multisite() ) {
	// Delete table for all sites in network
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		q_email_log_delete_db_data();
		restore_current_blog();
	}
} else {
	q_email_log_delete_db_data();
}

function q_email_log_delete_db_data() {
	global $wpdb;

	$remove_data_on_uninstall = false;

	$option = get_option( 'q_email_log_settings' );
	if ( is_array( $option ) && isset( $option['remove_on_uninstall'] ) && '1' === (string) $option['remove_on_uninstall'] ) {
		$remove_data_on_uninstall = true;
	}

	if ( $remove_data_on_uninstall ) {
		$table_name = $wpdb->prefix . 'q_email_log';
		$wpdb->query( "DROP TABLE IF EXISTS $table_name" );

		delete_option( 'q_email_log_db_version' );
		delete_option( 'q_email_log_settings' );

		// Clean up user capabilities
		$roles = get_editable_roles();
		foreach ( $roles as $role_name => $role_obj ) {
			$role = get_role( $role_name );
			if ( ! is_null( $role ) ) {
				$role->remove_cap( 'manage_q_email_logs' );
			}
		}
	}
}
