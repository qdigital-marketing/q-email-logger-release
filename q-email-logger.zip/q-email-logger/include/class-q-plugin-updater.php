<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QPluginUpdater {

    const CACHE_KEY = 'q_email_logger_update_release';
    const CACHE_TTL = 21600; // 6 hours.

    /**
     * Register WordPress plugin update hooks.
     */
    public static function init() {
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'check_for_update'));
        add_filter('plugins_api', array(__CLASS__, 'plugin_info'), 20, 3);
        add_filter('plugin_action_links_' . Q_EMAIL_LOG_BASENAME, array(__CLASS__, 'plugin_action_links'));
        add_filter('plugin_row_meta', array(__CLASS__, 'plugin_row_meta'), 10, 2);
    }

    /**
     * Add shortcut links below the plugin name.
     */
    public static function plugin_action_links($links) {
        $custom_links = array(
            'settings' => sprintf(
                '<a href="%1$s">%2$s</a>',
                esc_url(admin_url('admin.php?page=q-email-log-settings')),
                esc_html__('Settings', 'q-email-logger')
            ),
            'view_logs' => sprintf(
                '<a href="%1$s">%2$s</a>',
                esc_url(admin_url('admin.php?page=q-email-logger')),
                esc_html__('View Logs', 'q-email-logger')
            ),
        );

        return array_merge($custom_links, $links);
    }

    /**
     * Add plugin metadata links next to version and author.
     */
    public static function plugin_row_meta($links, $file) {
        if (Q_EMAIL_LOG_BASENAME !== $file) {
            return $links;
        }

        foreach ($links as $key => $link) {
            if (false !== strpos($link, 'Visit plugin site')) {
                unset($links[$key]);
            }
        }

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://github.com/' . Q_EMAIL_LOG_GITHUB_REPO . '/releases'),
            esc_html__('Releases', 'q-email-logger')
        );

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://github.com/' . Q_EMAIL_LOG_GITHUB_REPO . '/issues'),
            esc_html__('Support', 'q-email-logger')
        );

        $links[] = sprintf(
            '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
            esc_url('https://qdigital.com.au/'),
            esc_html__('Q Digital', 'q-email-logger')
        );

        return $links;
    }

    /**
     * Add GitHub release data to WordPress' plugin update transient.
     */
    public static function check_for_update($transient) {
        if (empty($transient) || !is_object($transient)) {
            return $transient;
        }

        if (empty($transient->checked) || !isset($transient->checked[Q_EMAIL_LOG_BASENAME])) {
            return $transient;
        }

        $release = self::get_latest_release();
        if (!$release || empty($release['version'])) {
            return $transient;
        }

        $update = self::build_update_object($release);

        if (empty($transient->response) || !is_array($transient->response)) {
            $transient->response = array();
        }

        if (empty($transient->no_update) || !is_array($transient->no_update)) {
            $transient->no_update = array();
        }

        if (version_compare($release['version'], Q_EMAIL_LOG_VERSION, '>')) {
            $transient->response[Q_EMAIL_LOG_BASENAME] = $update;
        } else {
            $transient->no_update[Q_EMAIL_LOG_BASENAME] = $update;
        }

        return $transient;
    }

    /**
     * Show release notes in the "View version details" modal.
     */
    public static function plugin_info($result, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug) || Q_EMAIL_LOG_SLUG !== $args->slug) {
            return $result;
        }

        $release = self::get_latest_release();
        if (!$release) {
            return $result;
        }

        $info = new \stdClass();
        $info->name = 'Q Email Logger';
        $info->slug = Q_EMAIL_LOG_SLUG;
        $info->version = $release['version'];
        $info->author = '<a href="https://qdigital.com.au/">Q Digital Marketing</a>';
        $info->homepage = 'https://github.com/' . Q_EMAIL_LOG_GITHUB_REPO;
        $info->requires = '4.0';
        $info->tested = Q_EMAIL_LOG_TESTED_UP_TO;
        $info->requires_php = '5.6';
        $info->download_link = $release['download_url'];
        $info->last_updated = $release['published_at'];
        $info->sections = array(
            'description' => 'Easily log and view all emails sent from WordPress.',
            'changelog'   => wp_kses_post(wpautop($release['body'] ? $release['body'] : 'No changelog provided.')),
        );
        $info->banners = array();
        $info->icons = array(
            '1x' => Q_EMAIL_LOG_URL . 'assets/img/logo-64x64.png',
        );

        return $info;
    }

    /**
     * Build the object shape WordPress expects in update_plugins.
     */
    private static function build_update_object($release) {
        $update = new \stdClass();
        $update->id = 'github.com/' . Q_EMAIL_LOG_GITHUB_REPO;
        $update->slug = Q_EMAIL_LOG_SLUG;
        $update->plugin = Q_EMAIL_LOG_BASENAME;
        $update->new_version = $release['version'];
        $update->url = 'https://github.com/' . Q_EMAIL_LOG_GITHUB_REPO;
        $update->package = $release['download_url'];
        $update->tested = Q_EMAIL_LOG_TESTED_UP_TO;
        $update->requires_php = '5.6';
        $update->icons = array(
            '1x' => Q_EMAIL_LOG_URL . 'assets/img/logo-64x64.png',
        );

        return $update;
    }

    /**
     * Fetch and normalize GitHub's latest release.
     */
    private static function get_latest_release() {
        $cached = get_site_transient(self::CACHE_KEY);
        if (false !== $cached) {
            return $cached;
        }

        $response = wp_remote_get(Q_EMAIL_LOG_RELEASE_API, array(
            'timeout' => 15,
            'headers' => array(
                'Accept' => 'application/vnd.github+json',
                'User-Agent' => 'Q-Email-Logger/' . Q_EMAIL_LOG_VERSION . '; ' . home_url('/'),
            ),
        ));

        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($data) || empty($data['tag_name'])) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        $download_url = self::get_download_url($data);
        if (!$download_url) {
            set_site_transient(self::CACHE_KEY, null, HOUR_IN_SECONDS);
            return null;
        }

        $release = array(
            'version' => ltrim($data['tag_name'], 'vV'),
            'download_url' => $download_url,
            'published_at' => !empty($data['published_at']) ? $data['published_at'] : '',
            'body' => !empty($data['body']) ? $data['body'] : '',
        );

        set_site_transient(self::CACHE_KEY, $release, self::CACHE_TTL);

        return $release;
    }

    /**
     * Use only curated plugin assets with the expected top-level folder.
     */
    private static function get_download_url($data) {
        if (!empty($data['assets']) && is_array($data['assets'])) {
            foreach ($data['assets'] as $asset) {
                if (!empty($asset['name']) && Q_EMAIL_LOG_SLUG . '.zip' === $asset['name'] && !empty($asset['browser_download_url'])) {
                    return $asset['browser_download_url'];
                }
            }
        }

        return '';
    }
}
