<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QHelper {

    /**
     * Perform additional sanitation of emails.
     */
    public static function sanitize_email($email, $multiple = true) {
        $emails = explode(',', $email);
        if (!$multiple) {
            $emails = array_slice($emails, 0, 1);
        }

        $cleaned_emails = array_map([__CLASS__, 'sanitize_email_with_name'], $emails);

        return implode(', ', $cleaned_emails);
    }

    /**
     * Sanitize email with name.
     */
    public static function sanitize_email_with_name($string) {
        $string = trim($string);

        $bracket_pos = strpos($string, '<');
        if (false !== $bracket_pos) {
            if ($bracket_pos > 0) {
                $name = substr($string, 0, $bracket_pos);
                $name = trim($name);

                $email = substr($string, $bracket_pos + 1);
                $email = str_replace('>', '', $email);

                return sanitize_text_field($name) . ' <' . \sanitize_email($email) . '>';
            }
        }

        return \sanitize_email($string);
    }

    /**
     * Checks the Checkbox when values are present in a given array.
     */
    public static function checked_array($values, $current) {
        if (!is_array($values)) {
            return;
        }

        if (in_array($current, $values, true)) {
            echo "checked='checked'";
        }
    }

    /**
     * Stringify arrays.
     */
    public static function stringify($may_be_array, $delimiter = ',') {
        if (!is_array($may_be_array)) {
            return (string) $may_be_array;
        }

        return implode($delimiter, $may_be_array);
    }

    /**
     * Gets the User defined Date time format.
     */
    public static function get_user_defined_date_time_format() {
        return sprintf('%1$s %2$s', get_option('date_format', 'Y-m-d'), get_option('time_format', 'g:i a'));
    }

    /**
     * Get the display format for displaying the email log time.
     */
    public static function get_display_format_for_log_time() {
        $default_time_format = get_option('time_format', 'g:i:s a');

        if (false === stripos($default_time_format, 's')) {
            $default_time_format = __('g:i:s a', 'q-email-logger');
        }

        return apply_filters('q_el_log_time_display_format', $default_time_format);
    }

    /**
     * Get Client IP Address.
     */
    public static function get_client_ip() {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        } else if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else if (isset($_SERVER['HTTP_X_FORWARDED'])) {
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        } else if (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        } else if (isset($_SERVER['HTTP_FORWARDED'])) {
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        } else if (isset($_SERVER['REMOTE_ADDR'])) {
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        }

        if (!empty($ipaddress) && strpos($ipaddress, ',') !== false) {
            $ip_parts  = explode(',', $ipaddress);
            $ipaddress = trim($ip_parts[0]);
        }

        return sanitize_text_field($ipaddress);
    }

    /**
     * Check if advanced search term.
     */
    public static function is_advanced_search_term($term) {
        if (!is_string($term)) {
            return false;
        }

        $predicates = self::get_advanced_search_term_predicates($term);

        return !empty($predicates);
    }

    /**
     * Get predicates for advanced search.
     */
    public static function get_advanced_search_term_predicates($term) {
        if (!is_string($term)) {
            return [];
        }

        $predicates           = explode(' ', $term);
        $predicates_organized = [];

        foreach ($predicates as $predicate) {
            $is_match = preg_match('/(id|email|to|cc|bcc|reply-to):(.*)$/', $predicate, $matches);
            if (1 === $is_match) {
                $predicates_organized[$matches[1]] = $matches[2];
            }
        }

        return $predicates_organized;
    }

    /**
     * Parse headers of an email to key-value pairs.
     */
    public static function parse_headers($headers) {
        $data = [];
        if (empty($headers)) {
            return $data;
        }

        $arr_headers = is_array($headers) ? $headers : explode("\n", $headers);

        foreach ($arr_headers as $header) {
            $header = trim($header);
            if (empty($header)) {
                continue;
            }
            $split_header = explode(':', $header, 2);
            if (count($split_header) < 2) {
                continue;
            }
            $key = strtolower(trim($split_header[0]));
            $value = trim($split_header[1]);

            if ($value != '') {
                switch ($key) {
                    case 'from':
                        $data['from'] = $value;
                        break;
                    case 'cc':
                        $data['cc'] = $value;
                        break;
                    case 'bcc':
                        $data['bcc'] = $value;
                        break;
                    case 'reply-to':
                        $data['reply_to'] = $value;
                        break;
                    case 'content-type':
                        $data['content_type'] = $value;
                        break;
                }
            }
        }

        return $data;
    }
}
