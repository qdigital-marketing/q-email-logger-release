<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QLogger {

    public function load() {
        add_filter('wp_mail', [$this, 'log_email']);
        add_action('wp_mail_failed', [$this, 'on_email_failed']);
        add_action('wp_mail_succeeded', [$this, 'on_email_succeeded']);

        // BuddyPress hooks
        add_action('bp_send_email_success', [$this, 'log_buddy_press_email'], 10, 2);
        add_action('bp_send_email_failure', [$this, 'log_buddy_press_email'], 10, 2);
    }

    /**
     * Logs email to database.
     */
    public function log_email($original_mail_info) {
        $original_mail_info = apply_filters('q_el_wp_mail_log', $original_mail_info);

        global $wp_version;
        $default_result = version_compare($wp_version, '5.9', '<') ? 1 : 0;
        $default_error = $default_result === 1 ? '' : __('Stopped by a plugin or failed before sending.', 'q-email-logger');

        $mail_info = wp_parse_args(
            $original_mail_info,
            [
                'to'          => '',
                'subject'     => '',
                'message'     => '',
                'headers'     => '',
                'attachments' => [],
                'result'      => $default_result,
                'error_message' => $default_error,
            ]
        );

        $attachments_flag = empty($mail_info['attachments']) ? 'false' : 'true';
        $attachment_names = '';
        if (!empty($mail_info['attachments'])) {
            if (is_array($mail_info['attachments'])) {
                $attachment_names = implode(', ', array_map('basename', $mail_info['attachments']));
            } else {
                $attachment_names = basename($mail_info['attachments']);
            }
        }

        $log = [
            'to_email'        => QHelper::stringify($mail_info['to']),
            'subject'         => $mail_info['subject'],
            'message'         => $mail_info['message'],
            'headers'         => QHelper::stringify($mail_info['headers'], "\n"),
            'attachments'     => $attachments_flag,
            'attachment_name' => $attachment_names,
            'sent_date'       => current_time('mysql'),
            'ip_address'      => QHelper::get_client_ip(),
            'result'          => $mail_info['result'],
            'error_message'   => $mail_info['error_message'],
        ];

        $log = apply_filters('q_el_email_log_before_insert', $log, $original_mail_info);

        q_email_log()->db->insert_log($log);

        do_action('q_el_email_log_inserted', $log);

        return $original_mail_info;
    }

    /**
     * Updates the failed email in the DB.
     */
    public function on_email_failed($wp_error) {
        if (!is_wp_error($wp_error)) {
            return;
        }

        $mail_error_data = $wp_error->get_error_data('wp_mail_failed');
        $mail_error_message = $wp_error->get_error_message('wp_mail_failed');

        $this->mark_email_log_as_failed($mail_error_data, $mail_error_message);
    }

    /**
     * BuddyPress support.
     */
    public function log_buddy_press_email($status, $bp_mail) {
        if (!class_exists('\\BP_Email')) {
            return;
        }

        if (!($bp_mail instanceof \BP_Email)) {
            return;
        }

        $log = [
            'to'      => array_shift($bp_mail->get_to())->get_address(),
            'subject' => $bp_mail->get_subject('replace-tokens'),
            'message' => $bp_mail->get_content('replace-tokens'),
            'headers' => $bp_mail->get_headers('replace-tokens'),
            'result'  => $status ? 1 : 0,
            'error_message' => $status ? '' : __('BuddyPress email failed.', 'q-email-logger'),
        ];

        $this->log_email($log);
    }

    /**
     * Updates the succeeded email in the DB.
     */
    public function on_email_succeeded($mail_data) {
        if (!is_array($mail_data)) {
            return;
        }

        $this->mark_email_log_as_succeeded($mail_data);
    }

    /**
     * Mark email log as failed.
     */
    protected function mark_email_log_as_failed($log, $error_message = '') {
        if (!is_array($log)) {
            return;
        }

        if (!isset($log['to'], $log['subject'])) {
            return;
        }

        $log_item_id = q_email_log()->db->fetch_log_id_by_data($log);

        if (empty($log_item_id)) {
            return;
        }

        q_email_log()->db->mark_log_as_failed($log_item_id, $error_message);
    }

    /**
     * Mark email log as succeeded.
     */
    protected function mark_email_log_as_succeeded($log) {
        if (!is_array($log)) {
            return;
        }

        if (!isset($log['to'], $log['subject'])) {
            return;
        }

        $log_item_id = q_email_log()->db->fetch_log_id_by_data($log);

        if (empty($log_item_id)) {
            return;
        }

        q_email_log()->db->mark_log_as_succeeded($log_item_id);
    }
}
