<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QAdmin {

    const CAPABILITY = 'manage_q_email_logs';
    const SETTINGS_PAGE_SLUG = 'q-email-log-settings';
    const LOG_LIST_PAGE_SLUG = 'q-email-logger';

    public function load() {
        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_init', [$this, 'register_settings_and_process_actions']);
        add_action('wp_ajax_q-el-view-message', [$this, 'view_log_message']);
        add_action('wp_ajax_q-el-autocomplete', [$this, 'autocomplete_logs']);
        add_action('wp_dashboard_setup', [$this, 'register_dashboard_widget']);
        add_filter('set-screen-option', [$this, 'save_screen_options'], 10, 3);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('q_el_email_log_inserted', [$this, 'check_database_size_alert']);
    }

    /**
     * Set up administrator capabilities upon activation.
     */
    public static function activate() {
        $role = get_role('administrator');
        if (!is_null($role)) {
            $role->add_cap(self::CAPABILITY);
        }

        // Initialize default settings if not exists
        if (false === get_option('q_email_log_settings')) {
            update_option('q_email_log_settings', [
                'allowed_roles'         => [],
                'remove_on_uninstall'   => '0',
                'disable_widget'        => '0',
                'auto_cleanup'          => '0',
                'auto_cleanup_days'     => 90,
                'alert_size_enabled'    => '0',
                'alert_size_threshold'  => 1000,
                'alert_size_email'      => get_option('admin_email'),
            ]);
        }
    }

    /**
     * Register main menu and submenus.
     */
    public function register_menu() {
        $page_hook = add_menu_page(
            __('Q Email Logger', 'q-email-logger'),
            __('Email Logger', 'q-email-logger'),
            self::CAPABILITY,
            self::LOG_LIST_PAGE_SLUG,
            [$this, 'render_log_list_page'],
            'dashicons-email-alt',
            26
        );

        add_submenu_page(
            self::LOG_LIST_PAGE_SLUG,
            __('View Logs', 'q-email-logger'),
            __('View Logs', 'q-email-logger'),
            self::CAPABILITY,
            self::LOG_LIST_PAGE_SLUG,
            [$this, 'render_log_list_page']
        );

        add_submenu_page(
            self::LOG_LIST_PAGE_SLUG,
            __('Settings', 'q-email-logger'),
            __('Settings', 'q-email-logger'),
            'manage_options',
            self::SETTINGS_PAGE_SLUG,
            [$this, 'render_settings_page']
        );

        add_action("load-{$page_hook}", [$this, 'load_screen_options']);
    }

    /**
     * Add per page screen options.
     */
    public function load_screen_options() {
        $screen = get_current_screen();
        if ($screen) {
            $screen->add_option('per_page', [
                'label'   => __('Entries per page', 'q-email-logger'),
                'default' => 20,
                'option'  => 'q_email_log_per_page',
            ]);
        }
    }

    /**
     * Return custom per_page setting.
     */
    public function get_per_page() {
        $screen = get_current_screen();
        $per_page = 20;

        if ($screen) {
            $option = $screen->get_option('per_page', 'option');
            if ($option) {
                $per_page = get_user_meta(get_current_user_id(), $option, true);
            }
            if (empty($per_page) || $per_page < 1) {
                $default = $screen->get_option('per_page', 'default');
                $per_page = !is_null($default) ? $default : 20;
            }
        }

        $per_page = absint($per_page);
        return $per_page > 0 ? $per_page : 20;
    }

    /**
     * Save screen options.
     */
    public function save_screen_options($status, $option, $value) {
        if ('q_email_log_per_page' === $option) {
            return $value;
        }
        return $status;
    }

    /**
     * Register dashboard widget.
     */
    public function register_dashboard_widget() {
        $settings = get_option('q_email_log_settings', []);
        if (isset($settings['disable_widget']) && $settings['disable_widget'] === '1') {
            return;
        }

        wp_add_dashboard_widget(
            'q_email_log_dashboard_widget',
            __('Q Email Logger Summary', 'q-email-logger'),
            [$this, 'render_dashboard_widget_content']
        );
    }

    /**
     * Render dashboard widget content.
     */
    public function render_dashboard_widget_content() {
        $count = q_email_log()->db->get_logs_count();
        ?>
        <p>
            <?php esc_html_e('Total number of emails logged:', 'q-email-logger'); ?>
            <strong><?php echo number_format(absint($count), 0, ',', ','); ?></strong>
        </p>
        <ul class="subsubsub" style="float: none; margin: 0; padding: 0;">
            <li><a href="<?php echo esc_url(admin_url('admin.php?page=' . self::LOG_LIST_PAGE_SLUG)); ?>"><?php esc_html_e('View Logs', 'q-email-logger'); ?></a> <span style="color: #ddd"> | </span></li>
            <li><a href="<?php echo esc_url(admin_url('admin.php?page=' . self::SETTINGS_PAGE_SLUG)); ?>"><?php esc_html_e('Settings', 'q-email-logger'); ?></a></li>
        </ul>
        <div class="clear"></div>
        <?php
    }

    /**
     * Enqueue CSS/JS files on log pages.
     */
    public function enqueue_assets($hook) {
        if (
            false === strpos($hook, 'q-email-logger') && 
            false === strpos($hook, 'q_email_logger') && 
            false === strpos($hook, 'q-email-log') && 
            false === strpos($hook, 'q_email_log')
        ) {
            return;
        }

        add_thickbox();

        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_script('jquery-ui-tooltip');
        wp_enqueue_script('jquery-ui-tabs');
        wp_enqueue_script('jquery-ui-autocomplete');
        wp_enqueue_script('jquery-ui-dialog');

        wp_register_script('q-insertion-q', Q_EMAIL_LOG_URL . 'assets/js/insQ.min.js', ['jquery'], '1.0.4', true);
        wp_enqueue_script('q-email-log-admin-js', Q_EMAIL_LOG_URL . 'assets/js/q-email-log-admin.js', ['q-insertion-q', 'jquery-ui-core', 'jquery-ui-datepicker', 'jquery-ui-tooltip', 'jquery-ui-tabs', 'jquery-ui-autocomplete', 'jquery-ui-dialog'], Q_EMAIL_LOG_VERSION, true);

        wp_enqueue_style('q-jquery-ui-css', Q_EMAIL_LOG_URL . 'assets/css/email-log-jquery-ui.min.css', []);
        wp_enqueue_style('q-email-log-google-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', [], null);
        wp_enqueue_style('q-email-log-admin-css', Q_EMAIL_LOG_URL . 'assets/css/q-email-log-admin.css', [], Q_EMAIL_LOG_VERSION);
        wp_enqueue_style('wp-jquery-ui-dialog');
    }

    /**
     * AJAX action to view message.
     */
    public function view_log_message() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(__('Permission denied.', 'q-email-logger'));
        }

        $id = isset($_GET['log_id']) ? absint($_GET['log_id']) : 0;
        if ($id <= 0) {
            wp_die(__('Invalid log ID.', 'q-email-logger'));
        }

        $log_items = q_email_log()->db->fetch_log_items_by_id([$id]);
        if (empty($log_items)) {
            wp_die(__('Log entry not found.', 'q-email-logger'));
        }

        $item = $log_items[0];
        $headers = QHelper::parse_headers($item['headers']);

        $active_tab = 0;
        if (isset($headers['content_type']) && false !== strpos(strtolower($headers['content_type']), 'text/html')) {
            $active_tab = 1;
        }

        ob_start();
        ?>
        <div class="q-email-log-modal-content">
            <table class="q-email-log-modal-header-table">
                <tr>
                    <th><?php esc_html_e('Sent at', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($item['sent_date']); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('To', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($item['to_email']); ?></td>
                </tr>
                <tr>
                    <th><?php esc_html_e('Subject', 'q-email-logger'); ?>:</th>
                    <td><strong><?php echo esc_html($item['subject']); ?></strong></td>
                </tr>
                <?php if (!empty($headers['from'])) : ?>
                <tr>
                    <th><?php esc_html_e('From', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($headers['from']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($headers['cc'])) : ?>
                <tr>
                    <th><?php esc_html_e('CC', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($headers['cc']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($headers['bcc'])) : ?>
                <tr>
                    <th><?php esc_html_e('BCC', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($headers['bcc']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($headers['reply_to'])) : ?>
                <tr>
                    <th><?php esc_html_e('Reply-To', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($headers['reply_to']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($item['attachment_name'])) : ?>
                <tr>
                    <th><?php esc_html_e('Attachments', 'q-email-logger'); ?>:</th>
                    <td><?php echo esc_html($item['attachment_name']); ?></td>
                </tr>
                <?php endif; ?>
                <?php if (!empty($item['ip_address'])) : ?>
                <tr>
                    <th><?php esc_html_e('IP Address', 'q-email-logger'); ?>:</th>
                    <td><code><?php echo esc_html($item['ip_address']); ?></code></td>
                </tr>
                <?php endif; ?>
                <?php if (!$item['result']) : ?>
                <tr class="failed-row">
                    <th><?php esc_html_e('Error Message', 'q-email-logger'); ?>:</th>
                    <td class="error-msg"><?php echo esc_html($item['error_message'] ?: __('Unknown error', 'q-email-logger')); ?></td>
                </tr>
                <?php endif; ?>
            </table>

            <div id="tabs" style="margin-top: 15px;">
                <ul data-active-tab="<?php echo absint($active_tab); ?>">
                    <li><a href="#tabs-text"><?php esc_html_e('Raw Email Content', 'q-email-logger'); ?></a></li>
                    <li><a href="#tabs-preview"><?php esc_html_e('HTML Preview', 'q-email-logger'); ?></a></li>
                </ul>

                <div id="tabs-text">
                    <pre class="tabs-text-pre"><?php echo esc_html($item['message']); ?></pre>
                </div>

                <div id="tabs-preview">
                    <div class="html-preview-container">
                        <?php echo wp_kses($item['message'], $this->allowed_html_tags_for_preview()); ?>
                    </div>
                </div>
            </div>

            <div id="view-message-footer" style="margin-top: 15px; text-align: right;">
                <a href="#" class="button button-secondary" id="thickbox-footer-close"><?php esc_html_e('Close', 'q-email-logger'); ?></a>
            </div>
        </div>
        <?php
        echo ob_get_clean();
        wp_die();
    }

    /**
     * AJAX action for autocomplete inputs.
     */
    public function autocomplete_logs() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_send_json_error(__('Permission denied.', 'q-email-logger'));
        }

        $type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
        $term = isset($_GET['term']) ? sanitize_text_field($_GET['term']) : '';

        if (empty($type) || empty($term)) {
            wp_send_json([]);
        }

        $results = [];
        if ($type === 'recipient') {
            $results = q_email_log()->db->search_recipients($term);
        } elseif ($type === 'subject') {
            $results = q_email_log()->db->search_subjects($term);
        }

        wp_send_json($results);
    }

    /**
     * Allowed tags for HTML email preview.
     */
    protected function allowed_html_tags_for_preview() {
        $allowed = wp_kses_allowed_html('post');
        $allowed['link'] = [
            'rel'   => true,
            'href'  => true,
            'type'  => true,
            'media' => true,
        ];
        $allowed['style'] = [
            'type' => true,
        ];
        return $allowed;
    }

    /**
     * Register settings and process synchronous actions.
     */
    public function register_settings_and_process_actions() {
        register_setting(
            'q_email_log_settings_group',
            'q_email_log_settings',
            [$this, 'sanitize_settings']
        );

        // Daily cleanup check
        $this->daily_logs_cleanup();

        // Process GET/POST actions
        $this->process_log_actions();

        // Process Test Email sending
        if (isset($_POST['q_send_test_email_nonce']) && wp_verify_nonce($_POST['q_send_test_email_nonce'], 'q_send_test_email_action')) {
            if (current_user_can('manage_options')) {
                $to = isset($_POST['q_test_email_to']) ? sanitize_email($_POST['q_test_email_to']) : '';
                $subject = isset($_POST['q_test_email_subject']) ? sanitize_text_field($_POST['q_test_email_subject']) : '';
                $message = isset($_POST['q_test_email_message']) ? wp_kses_post($_POST['q_test_email_message']) : '';

                if (is_email($to) && !empty($subject) && !empty($message)) {
                    $headers = ['Content-Type: text/html; charset=UTF-8'];
                    $sent = wp_mail($to, $subject, $message, $headers);
                    if ($sent) {
                        $redirect_url = add_query_arg('test_email', 'success', admin_url('admin.php?page=' . self::SETTINGS_PAGE_SLUG));
                    } else {
                        $redirect_url = add_query_arg('test_email', 'failed', admin_url('admin.php?page=' . self::SETTINGS_PAGE_SLUG));
                    }
                } else {
                    $redirect_url = add_query_arg('test_email', 'invalid', admin_url('admin.php?page=' . self::SETTINGS_PAGE_SLUG));
                }
                wp_redirect($redirect_url);
                exit;
            }
        }
    }

    /**
     * Handle actions like delete, bulk delete, clear all.
     */
    protected function process_log_actions() {
        $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
        if (self::LOG_LIST_PAGE_SLUG !== $page) {
            return;
        }

        $action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        if (empty($action) && isset($_GET['action2'])) {
            $action = sanitize_text_field($_GET['action2']);
        }

        if (empty($action)) {
            return;
        }

        if ('delete' === $action) {
            $id = isset($_GET['log']) ? absint($_GET['log']) : 0;
            if ($id > 0) {
                if (wp_verify_nonce($_GET['_wpnonce'], 'q_el_delete_log_' . $id)) {
                    if (current_user_can(self::CAPABILITY)) {
                        $deleted = q_email_log()->db->delete_logs((string) $id);
                        $this->add_deleted_notice($deleted);
                    }
                }
            }
        } elseif ('bulk-delete' === $action) {
            $ids = isset($_GET['log']) ? array_map('absint', (array) $_GET['log']) : [];
            if (!empty($ids)) {
                if (wp_verify_nonce($_GET['_wpnonce'] ?? '', 'bulk-q-email-logs')) {
                    if (current_user_can(self::CAPABILITY)) {
                        $deleted = q_email_log()->db->delete_logs(implode(',', $ids));
                        $this->add_deleted_notice($deleted);
                    }
                }
            }
        } elseif ('clear-all' === $action) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'q_el_clear_all_logs')) {
                if (current_user_can(self::CAPABILITY)) {
                    $deleted = q_email_log()->db->delete_all_logs();
                    $this->add_deleted_notice($deleted);
                }
            }
        }

        // Clean up URL and redirect to prevent double execution
        if (!empty($action)) {
            wp_redirect(remove_query_arg(['action', 'action2', 'log', '_wpnonce', 'q-email-logger']));
            exit;
        }
    }

    /**
     * Add settings error for deletion.
     */
    protected function add_deleted_notice($count) {
        if ($count !== false && $count > 0) {
            $message = sprintf(_n('%s email log deleted.', '%s email logs deleted.', $count, 'q-email-logger'), $count);
            add_settings_error('q-email-log-notices', 'logs_deleted', $message, 'updated');
        } else {
            add_settings_error('q-email-log-notices', 'logs_deleted_failed', __('Error in deleting the logs.', 'q-email-logger'), 'error');
        }
    }

    /**
     * Process daily logs cleanup.
     */
    public function daily_logs_cleanup() {
        if (get_transient('q_email_log_cleanup_transient')) {
            return;
        }

        $settings = get_option('q_email_log_settings', []);
        if (isset($settings['auto_cleanup']) && $settings['auto_cleanup'] === '1') {
            $days = isset($settings['auto_cleanup_days']) ? absint($settings['auto_cleanup_days']) : 90;
            if ($days > 0) {
                q_email_log()->db->delete_logs_older_than($days);
            }
        }

        set_transient('q_email_log_cleanup_transient', '1', DAY_IN_SECONDS);
    }

    /**
     * Sanitize settings array.
     */
    public function sanitize_settings($input) {
        $output = get_option('q_email_log_settings', []);
        if (!is_array($output)) {
            $output = [];
        }

        // Allowed Roles (array format)
        $old_roles = isset($output['allowed_roles']) ? (array) $output['allowed_roles'] : [];
        $new_roles = isset($input['allowed_roles']) ? (array) $input['allowed_roles'] : [];
        $new_roles = array_map('sanitize_text_field', $new_roles);
        $output['allowed_roles'] = $new_roles;

        // Sync capabilities
        $this->update_capabilities_for_roles($old_roles, $new_roles);

        // Remove on Uninstall
        $output['remove_on_uninstall'] = isset($input['remove_on_uninstall']) && $input['remove_on_uninstall'] === '1' ? '1' : '0';

        // Disable Widget
        $output['disable_widget'] = isset($input['disable_widget']) && $input['disable_widget'] === '1' ? '1' : '0';

        // Auto Cleanup
        $output['auto_cleanup'] = isset($input['auto_cleanup']) && $input['auto_cleanup'] === '1' ? '1' : '0';
        $output['auto_cleanup_days'] = isset($input['auto_cleanup_days']) ? max(1, absint($input['auto_cleanup_days'])) : 90;

        // Database Threshold Alert
        $output['alert_size_enabled'] = isset($input['alert_size_enabled']) && $input['alert_size_enabled'] === '1' ? '1' : '0';
        $output['alert_size_threshold'] = isset($input['alert_size_threshold']) ? absint($input['alert_size_threshold']) : 1000;
        $output['alert_size_email'] = isset($input['alert_size_email']) && !empty($input['alert_size_email']) ? sanitize_email($input['alert_size_email']) : get_option('admin_email');

        return $output;
    }

    /**
     * Helper to update capabilities across roles.
     */
    protected function update_capabilities_for_roles($old_roles, $new_roles) {
        $removed = array_diff($old_roles, $new_roles);
        $added = array_diff($new_roles, $old_roles);

        foreach ($removed as $role_name) {
            $role = get_role($role_name);
            if (!is_null($role)) {
                $role->remove_cap(self::CAPABILITY);
            }
        }

        foreach ($added as $role_name) {
            $role = get_role($role_name);
            if (!is_null($role)) {
                $role->add_cap(self::CAPABILITY);
            }
        }
    }

    /**
     * Check database size alert.
     */
    public function check_database_size_alert($log) {
        $settings = get_option('q_email_log_settings', []);
        if (isset($settings['alert_size_enabled']) && $settings['alert_size_enabled'] === '1') {
            $threshold = isset($settings['alert_size_threshold']) ? absint($settings['alert_size_threshold']) : 1000;
            $email = isset($settings['alert_size_email']) && !empty($settings['alert_size_email']) ? $settings['alert_size_email'] : get_option('admin_email');

            $count = q_email_log()->db->get_logs_count();
            if ($count >= $threshold) {
                // Prevent duplicate alerts within 24 hours
                if (!get_transient('q_email_log_alert_sent_transient')) {
                    $subject = sprintf(__('[Q Email Logger] Database limit reached on %s', 'q-email-logger'), get_bloginfo('name'));
                    $message = sprintf(
                        __("Hello Admin,\n\nThis is an automated alert from Q Email Logger. The number of logged emails on your WordPress site (%s) has reached or exceeded your threshold limit of %d logs.\n\nCurrent log count: %d\n\nPlease visit the logs page to manage your database logs:\n%s\n\nBest regards,\nQ Email Logger", 'q-email-logger'),
                        get_bloginfo('name'),
                        $threshold,
                        $count,
                        admin_url('admin.php?page=' . self::LOG_LIST_PAGE_SLUG)
                    );

                    // Temporarily remove the hook to avoid infinite loop if wp_mail triggers it again
                    remove_action('q_el_email_log_inserted', [$this, 'check_database_size_alert']);
                    wp_mail($email, $subject, $message);
                    add_action('q_el_email_log_inserted', [$this, 'check_database_size_alert']);

                    set_transient('q_email_log_alert_sent_transient', '1', DAY_IN_SECONDS);
                }
            }
        }
    }

    /**
     * Render the logs list table view.
     */
    public function render_log_list_page() {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'q-email-logger'));
        }

        $list_table = new QListTable($this);
        $list_table->prepare_items();
        ?>
        <div class="wrap q-email-log-wrap">
            <h1 class="q-email-log-title">
                <img class="q-el-logo" src="<?php echo esc_url(Q_EMAIL_LOG_URL . 'assets/img/q-logo.png'); ?>" alt="Logo" />
                <?php esc_html_e('Q Email Logger', 'q-email-logger'); ?>
            </h1>

            <?php settings_errors('q-email-log-notices'); ?>

            <div class="q-email-log-content">
                <form id="q-email-logs-list" method="get">
                    <input type="hidden" name="page" value="<?php echo esc_attr(self::LOG_LIST_PAGE_SLUG); ?>">
                    <?php $list_table->search_box(__('Search Logs', 'q-email-logger'), 'search_id'); ?>
                    <?php
                    wp_nonce_field('bulk-q-email-logs');
                    $list_table->display();
                    ?>
                </form>
            </div>
        </div>
        <?php
    }

    /**
     * Render the settings page.
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'q-email-logger'));
        }

        $settings = get_option('q_email_log_settings', []);
        $selected_roles = isset($settings['allowed_roles']) ? (array) $settings['allowed_roles'] : [];
        $remove_on_uninstall = isset($settings['remove_on_uninstall']) ? $settings['remove_on_uninstall'] : '0';
        $disable_widget = isset($settings['disable_widget']) ? $settings['disable_widget'] : '0';
        $auto_cleanup = isset($settings['auto_cleanup']) ? $settings['auto_cleanup'] : '0';
        $auto_cleanup_days = isset($settings['auto_cleanup_days']) ? absint($settings['auto_cleanup_days']) : 90;
        $alert_size_enabled = isset($settings['alert_size_enabled']) ? $settings['alert_size_enabled'] : '0';
        $alert_size_threshold = isset($settings['alert_size_threshold']) ? absint($settings['alert_size_threshold']) : 1000;
        $alert_size_email = isset($settings['alert_size_email']) ? $settings['alert_size_email'] : get_option('admin_email');

        $available_roles = get_editable_roles();
        unset($available_roles['administrator']);
        ?>
        <div class="wrap q-email-log-wrap">
            <h1 class="q-email-log-title">
                <img class="q-el-logo" src="<?php echo esc_url(Q_EMAIL_LOG_URL . 'assets/img/q-logo.png'); ?>" alt="Logo" />
                <?php esc_html_e('Q Email Logger Settings', 'q-email-logger'); ?>
            </h1>

            <?php settings_errors(); ?>

            <?php
            if (isset($_GET['test_email'])) {
                $status = sanitize_text_field($_GET['test_email']);
                if ('success' === $status) {
                    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Test email sent successfully! Check your inbox or the logs to verify.', 'q-email-logger') . '</p></div>';
                } elseif ('failed' === $status) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('WordPress failed to send the test email. Please check your mail server configuration.', 'q-email-logger') . '</p></div>';
                } elseif ('invalid' === $status) {
                    echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid email address, subject, or message.', 'q-email-logger') . '</p></div>';
                }
            }
            ?>

            <div class="q-email-log-settings-container">
                <div class="q-settings-layout">

                    <!-- Main Column -->
                    <div class="q-settings-main">
                        <form method="post" action="options.php">
                            <?php settings_fields('q_email_log_settings_group'); ?>

                            <!-- Access Control -->
                            <div class="q-card">
                                <div class="q-card-header">
                                    <h2><span class="dashicons dashicons-admin-users"></span> <?php esc_html_e('Access Control', 'q-email-logger'); ?></h2>
                                </div>
                                <div class="q-card-body">
                                    <div class="q-form-row">
                                        <label class="q-label"><?php esc_html_e('Allowed User Roles', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <div class="q-checkbox-list">
                                                <label class="q-checkbox-label disabled">
                                                    <input type="checkbox" checked disabled />
                                                    <span><strong><?php esc_html_e('Administrator', 'q-email-logger'); ?></strong></span>
                                                </label>
                                                <?php foreach ($available_roles as $role_id => $role) : ?>
                                                    <label class="q-checkbox-label">
                                                        <input type="checkbox" name="q_email_log_settings[allowed_roles][]" value="<?php echo esc_attr($role_id); ?>" <?php checked(in_array($role_id, $selected_roles, true)); ?> />
                                                        <span><?php echo esc_html($role['name']); ?></span>
                                                    </label>
                                                <?php endforeach; ?>
                                            </div>
                                            <p class="q-help-text"><?php esc_html_e('Select which user roles can access the email logs. Administrators always have access.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- General Settings -->
                            <div class="q-card">
                                <div class="q-card-header">
                                    <h2><span class="dashicons dashicons-admin-generic"></span> <?php esc_html_e('General Settings', 'q-email-logger'); ?></h2>
                                </div>
                                <div class="q-card-body">
                                    <div class="q-form-row q-toggle-row">
                                        <label class="q-label" for="q_remove_on_uninstall"><?php esc_html_e('Remove Data on Uninstall', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <label class="q-switch">
                                                <input type="checkbox" id="q_remove_on_uninstall" name="q_email_log_settings[remove_on_uninstall]" value="1" <?php checked('1', $remove_on_uninstall); ?> />
                                                <span class="q-slider"></span>
                                            </label>
                                            <p class="q-help-text"><?php esc_html_e('Permanently delete all logs and settings when this plugin is uninstalled.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>

                                    <div class="q-form-row q-toggle-row">
                                        <label class="q-label" for="q_disable_widget"><?php esc_html_e('Disable Dashboard Widget', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <label class="q-switch">
                                                <input type="checkbox" id="q_disable_widget" name="q_email_log_settings[disable_widget]" value="1" <?php checked('1', $disable_widget); ?> />
                                                <span class="q-slider"></span>
                                            </label>
                                            <p class="q-help-text"><?php esc_html_e('Hide the email summary widget from the WordPress dashboard.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Auto Delete Logs -->
                            <div class="q-card">
                                <div class="q-card-header">
                                    <h2><span class="dashicons dashicons-trash"></span> <?php esc_html_e('Auto Delete Logs', 'q-email-logger'); ?></h2>
                                </div>
                                <div class="q-card-body">
                                    <div class="q-form-row q-toggle-row">
                                        <label class="q-label" for="q_auto_cleanup"><?php esc_html_e('Enable Auto Delete', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <label class="q-switch">
                                                <input type="checkbox" id="q_auto_cleanup" name="q_email_log_settings[auto_cleanup]" value="1" <?php checked('1', $auto_cleanup); ?> />
                                                <span class="q-slider"></span>
                                            </label>
                                            <p class="q-help-text"><?php esc_html_e('Automatically remove old logs to keep your database clean.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>

                                    <div class="q-form-row q-conditional" style="<?php echo $auto_cleanup === '1' ? '' : 'display:none;'; ?>">
                                        <label class="q-label" for="q_auto_cleanup_days"><?php esc_html_e('Keep Logs For (Days)', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <input type="number" id="q_auto_cleanup_days" name="q_email_log_settings[auto_cleanup_days]" value="<?php echo esc_attr($auto_cleanup_days); ?>" min="1" class="regular-text q-input-number" />
                                            <p class="q-help-text"><?php esc_html_e('Logs older than this number of days will be automatically deleted.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Database Size Alert -->
                            <div class="q-card">
                                <div class="q-card-header">
                                    <h2><span class="dashicons dashicons-warning"></span> <?php esc_html_e('Database Size Alert', 'q-email-logger'); ?></h2>
                                </div>
                                <div class="q-card-body">
                                    <div class="q-form-row q-toggle-row">
                                        <label class="q-label" for="q_alert_size_enabled"><?php esc_html_e('Enable Size Alerts', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <label class="q-switch">
                                                <input type="checkbox" id="q_alert_size_enabled" name="q_email_log_settings[alert_size_enabled]" value="1" <?php checked('1', $alert_size_enabled); ?> />
                                                <span class="q-slider"></span>
                                            </label>
                                            <p class="q-help-text"><?php esc_html_e('Receive an email alert when the log count exceeds your threshold.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>

                                    <div class="q-conditional-alert" style="<?php echo $alert_size_enabled === '1' ? '' : 'display:none;'; ?>">
                                        <div class="q-form-row">
                                            <label class="q-label" for="q_alert_size_threshold"><?php esc_html_e('Threshold (Log Count)', 'q-email-logger'); ?></label>
                                            <div class="q-input-group">
                                                <input type="number" id="q_alert_size_threshold" name="q_email_log_settings[alert_size_threshold]" value="<?php echo esc_attr($alert_size_threshold); ?>" min="1" class="regular-text q-input-number" />
                                                <p class="q-help-text"><?php esc_html_e('An alert email will be sent once the number of stored logs reaches this value.', 'q-email-logger'); ?></p>
                                            </div>
                                        </div>

                                        <div class="q-form-row">
                                            <label class="q-label" for="q_alert_size_email"><?php esc_html_e('Alert Email Address', 'q-email-logger'); ?></label>
                                            <div class="q-input-group">
                                                <input type="email" id="q_alert_size_email" name="q_email_log_settings[alert_size_email]" value="<?php echo esc_attr($alert_size_email); ?>" class="regular-text q-input-text" />
                                                <p class="q-help-text"><?php esc_html_e('The email address that will receive size limit warnings.', 'q-email-logger'); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="q-submit-wrapper">
                                <?php submit_button(__('Save Settings', 'q-email-logger'), 'primary', 'submit', false, ['class' => 'q-btn-save']); ?>
                            </div>
                        </form>

                        <!-- Send Test Email -->
                        <div class="q-card" style="margin-top: 24px;">
                            <div class="q-card-header">
                                <h2><span class="dashicons dashicons-email-alt"></span> <?php esc_html_e('Send Test Email', 'q-email-logger'); ?></h2>
                            </div>
                            <div class="q-card-body">
                                <form method="post" action="">
                                    <?php wp_nonce_field('q_send_test_email_action', 'q_send_test_email_nonce'); ?>

                                    <div class="q-form-row">
                                        <label class="q-label" for="q_test_email_to"><?php esc_html_e('Send To', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <input type="email" id="q_test_email_to" name="q_test_email_to" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text q-input-text" required />
                                            <p class="q-help-text"><?php esc_html_e('The recipient email address for the test email.', 'q-email-logger'); ?></p>
                                        </div>
                                    </div>

                                    <div class="q-form-row">
                                        <label class="q-label" for="q_test_email_subject"><?php esc_html_e('Subject', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <input type="text" id="q_test_email_subject" name="q_test_email_subject" value="<?php echo esc_attr(__('Q Email Logger Test Email', 'q-email-logger')); ?>" class="regular-text q-input-text" required />
                                        </div>
                                    </div>

                                    <div class="q-form-row">
                                        <label class="q-label" for="q_test_email_message"><?php esc_html_e('Message (HTML)', 'q-email-logger'); ?></label>
                                        <div class="q-input-group">
                                            <textarea id="q_test_email_message" name="q_test_email_message" rows="5" class="large-text code" style="width: 100%; max-width: 400px;" required><?php
                                                echo esc_textarea(sprintf(__('<h1>Hello from Q Email Logger!</h1><p>This is a test email sent from <strong>%s</strong> to verify that email logging is working correctly.</p><p>If you see this log in your dashboard, the plugin is active and logging emails successfully!</p>', 'q-email-logger'), get_bloginfo('name')));
                                            ?></textarea>
                                        </div>
                                    </div>

                                    <div class="q-submit-wrapper">
                                        <?php submit_button(__('Send Test Email', 'q-email-logger'), 'secondary', 'q_send_test_email_submit', false); ?>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div><!-- /.q-settings-main -->

                    <!-- Sidebar -->
                    <div class="q-settings-sidebar">

                        <div class="q-info-card">
                            <div class="q-info-card-icon">
                                <span class="dashicons dashicons-shield"></span>
                            </div>
                            <h3><?php esc_html_e('Access Control', 'q-email-logger'); ?></h3>
                            <p><?php esc_html_e('Grant specific user roles access to view email logs. Administrators always retain full access regardless of this setting.', 'q-email-logger'); ?></p>
                        </div>

                        <div class="q-info-card">
                            <div class="q-info-card-icon">
                                <span class="dashicons dashicons-backup"></span>
                            </div>
                            <h3><?php esc_html_e('Auto Cleanup Tips', 'q-email-logger'); ?></h3>
                            <p><?php esc_html_e('Keeping logs indefinitely can slow your database. Recommended retention periods:', 'q-email-logger'); ?></p>
                            <ul>
                                <li><?php esc_html_e('Low traffic: 180 days', 'q-email-logger'); ?></li>
                                <li><?php esc_html_e('Medium traffic: 90 days', 'q-email-logger'); ?></li>
                                <li><?php esc_html_e('High traffic: 30 days', 'q-email-logger'); ?></li>
                            </ul>
                        </div>

                        <div class="q-info-card">
                            <div class="q-info-card-icon">
                                <span class="dashicons dashicons-email-alt"></span>
                            </div>
                            <h3><?php esc_html_e('Test Email', 'q-email-logger'); ?></h3>
                            <p><?php esc_html_e('Use the Send Test Email tool to confirm that WordPress email delivery and logging are both working correctly on your site.', 'q-email-logger'); ?></p>
                        </div>

                    </div><!-- /.q-settings-sidebar -->

                </div><!-- /.q-settings-layout -->
            </div><!-- /.q-email-log-settings-container -->
        </div><!-- /.wrap -->

        <script>
            jQuery(document).ready(function($) {
                // Conditional toggle for auto-delete
                $('#q_auto_cleanup').on('change', function() {
                    if ($(this).is(':checked')) {
                        $('.q-conditional').slideDown(200);
                    } else {
                        $('.q-conditional').slideUp(200);
                    }
                });

                // Conditional toggle for size alerts
                $('#q_alert_size_enabled').on('change', function() {
                    if ($(this).is(':checked')) {
                        $('.q-conditional-alert').slideDown(200);
                    } else {
                        $('.q-conditional-alert').slideUp(200);
                    }
                });
            });
        </script>
        <?php
    }
}
