<?php
/**
 * Plugin Name: Q Email Logger
 * Plugin URI: https://example.com/q-email-log
 * Description: Easily log and view all emails sent from WordPress.
 * Author: Q Digital Marketing
 * Author URI: https://qdigital.com.au/
 * Version: 1.0.5
 * Text Domain: q-email-logger
 * License: GPLv2 or later
 * Requires at least: 4.0
 * Tested up to: 7.0
 * Requires PHP: 5.6
 */

defined('ABSPATH') || exit; // Exit if accessed directly.

define('Q_EMAIL_LOG_FILE', __FILE__);
define('Q_EMAIL_LOG_PATH', plugin_dir_path(__FILE__));
define('Q_EMAIL_LOG_URL', plugin_dir_url(__FILE__));
define('Q_EMAIL_LOG_VERSION', '1.0.5');
define('Q_EMAIL_LOG_SLUG', 'q-email-logger');
define('Q_EMAIL_LOG_BASENAME', plugin_basename(__FILE__));
define('Q_EMAIL_LOG_GITHUB_REPO', 'qdigital-marketing/q-email-logger-release');
define('Q_EMAIL_LOG_RELEASE_API', 'https://api.github.com/repos/' . Q_EMAIL_LOG_GITHUB_REPO . '/releases/latest');

// Load helper functions
require_once Q_EMAIL_LOG_PATH . 'include/class-q-helper.php';

// Load Core classes
require_once Q_EMAIL_LOG_PATH . 'include/class-q-db.php';
require_once Q_EMAIL_LOG_PATH . 'include/class-q-logger.php';
require_once Q_EMAIL_LOG_PATH . 'include/class-q-list-table.php';
require_once Q_EMAIL_LOG_PATH . 'include/class-q-admin.php';
require_once Q_EMAIL_LOG_PATH . 'include/class-q-email-log.php';

if (is_admin()) {
    require_once Q_EMAIL_LOG_PATH . 'include/class-q-plugin-updater.php';
    \QEmailLog\QPluginUpdater::init();
}

// Instantiate the plugin
function q_email_log() {
    return \QEmailLog\QEmailLog::get_instance();
}

// Hook to load the plugin
add_action('plugins_loaded', function() {
    q_email_log()->load();
}, 99);

// Activation Hook
register_activation_hook(__FILE__, function() {
    // Setup database
    \QEmailLog\QDB::activate();
    // Setup admin capabilities
    \QEmailLog\QAdmin::activate();
});
