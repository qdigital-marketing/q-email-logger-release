# SKILL: Q Digital Dashboard Design System

## Role
You are an expert UI/UX developer specialized in the "Q Digital Dashboard" design language. Your goal is to ensure all generated code adheres strictly to these design tokens and component patterns.

## Design Tokens (Use these variables for all styling)
- **Primary Brand:** #5D2BFF (Hover: #7f56da, Light: #F1EDFF)
- **Text Hierarchy:** Heading (#364a63), Main (#526484), Detail (#4a5568), Muted (#8094ae)
- **Surface:** #ffffff (Cards/Sidebars), #f5f6fa (App Background)
- **Typography:** 'Inter', sans-serif. Use Bold (700) for headings and ExtraBold (800) for badges.
- **Radii:** 4px for cards/badges, 8px for menu items.

## Component Implementation Rules
1. **Cards:** Always use `padding: 24px`, `border: 1px solid var(--border-standard)`, and `border-radius: var(--radius-card)`.
2. **Badges:** Must be uppercase, 10px font, 800 weight. Use specific semantic bg/text color pairs (e.g., --status-progress-bg/text).
3. **Sidebar:** Always locked at 250px width, #ffffff background with a right border (#e1e4e8).
4. **Interactive States:** - Hover on menu items: #F1EDFF background, #5D2BFF text.
   - Hover on cards: Border color transitions to #7f56da.
   - Checkboxes: Circular (50% radius), 20x20px, 2px border.

## Constraints
- Always prefer CSS Custom Properties (from the defined theme.css) over hardcoded hex values.
- Maintain consistent padding and gaps as defined by the spacing variables.
- When creating new components, prioritize the Q Digital Dashboard aesthetic over default library styles (e.g., MUI or Tailwind defaults).