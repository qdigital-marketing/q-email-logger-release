(function($) {
    $(document).ready(function() {
        // Datepicker setup for Start Date & End Date
        if ($.isFunction($.fn.datepicker)) {
            $('.q-el-datepicker').datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'yy-mm-dd'
            });
        }

        // --- Recipient Tag Input Logic ---
        var $hiddenInput = $('#recipient_tags_hidden');
        var $tagInput = $('#recipient_input');
        var $tagsContainer = $('#q-el-tags-container');
        var tags = [];

        // Load existing tags on load
        if ($hiddenInput.length && $hiddenInput.val().trim() !== '') {
            tags = $hiddenInput.val().split(',').map(function(t) { return t.trim(); }).filter(Boolean);
            renderTags();
        }

        function renderTags() {
            $tagsContainer.empty();
            tags.forEach(function(tag, index) {
                var $tagEl = $('<span class="q-el-tag">' + tag + '<span class="q-el-tag-remove" data-index="' + index + '">&times;</span></span>');
                $tagsContainer.append($tagEl);
            });
            $hiddenInput.val(tags.join(','));
        }

        // Add tag on select from autocomplete, keydown space/comma/enter
        if ($.isFunction($.fn.autocomplete)) {
            $tagInput.autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: ajaxurl,
                        dataType: 'json',
                        data: {
                            action: 'q-el-autocomplete',
                            type: 'recipient',
                            term: request.term
                        },
                        success: function(data) {
                            response(data);
                        }
                    });
                },
                select: function(event, ui) {
                    var val = ui.item.value.trim();
                    if (val && tags.indexOf(val) === -1) {
                        tags.push(val);
                        renderTags();
                    }
                    $tagInput.val('');
                    return false;
                },
                minLength: 1
            });

            $('#subject_filter').autocomplete({
                source: function(request, response) {
                    $.ajax({
                        url: ajaxurl,
                        dataType: 'json',
                        data: {
                            action: 'q-el-autocomplete',
                            type: 'subject',
                            term: request.term
                        },
                        success: function(data) {
                            response(data);
                        }
                    });
                },
                minLength: 1
            });
        }

        $tagInput.on('keydown', function(e) {
            // Add tag on space, comma, or enter
            if (e.key === ' ' || e.key === ',' || e.key === 'Enter') {
                e.preventDefault();
                var val = $tagInput.val().trim().replace(/,/g, '');
                if (val && tags.indexOf(val) === -1) {
                    tags.push(val);
                    renderTags();
                }
                $tagInput.val('');
            } else if (e.key === 'Backspace' && $tagInput.val() === '' && tags.length > 0) {
                tags.pop();
                renderTags();
            }
        });

        $tagsContainer.on('click', '.q-el-tag-remove', function() {
            var idx = $(this).data('index');
            tags.splice(idx, 1);
            renderTags();
        });

        // Click wrapper to focus input
        $('.q-el-tag-input-wrapper').on('click', function(e) {
            if (e.target === this || $(e.target).attr('id') === 'q-el-tags-container') {
                $tagInput.focus();
            }
        });


        // --- Slide-out Side Panel (Replacing dialog popup) ---
        var $panel = $('#q-el-slideout-panel');
        var $overlay = $('#q-el-slideout-overlay');

        if (!$panel.length) {
            $overlay = $('<div id="q-el-slideout-overlay" class="q-el-slideout-overlay"></div>').appendTo('body');
            $panel = $(
                '<div id="q-el-slideout-panel" class="q-el-slideout-panel">' +
                    '<div class="q-el-slideout-header">' +
                        '<h3 class="q-el-slideout-title">Email Content</h3>' +
                        '<span class="q-el-slideout-close">&times;</span>' +
                    '</div>' +
                    '<div class="q-el-slideout-body"></div>' +
                '</div>'
            ).appendTo('body');
        }

        function closePanel() {
            $panel.removeClass('is-open');
            $overlay.removeClass('is-open');
            setTimeout(function() {
                $panel.find('.q-el-slideout-body').html('');
            }, 300);
        }

        function openPanel(title, ajaxUrl) {
            $panel.find('.q-el-slideout-title').text(title);
            $panel.find('.q-el-slideout-body').html('<div class="q-el-modal-loader"><span class="spinner is-active" style="float:none; margin: 100px auto; display: block;"></span></div>');
            
            $panel.addClass('is-open');
            $overlay.addClass('is-open');

            $.ajax({
                url: ajaxUrl,
                method: 'GET',
                success: function(response) {
                    $panel.find('.q-el-slideout-body').html(response);
                    
                    // Re-init jQuery UI tabs in response
                    if ($.isFunction($.fn.tabs) && $panel.find('#tabs').length) {
                        var activeTabIndex = parseInt($panel.find('#tabs ul').data('active-tab'));
                        activeTabIndex = isNaN(activeTabIndex) ? 0 : activeTabIndex;
                        $panel.find('#tabs').tabs({ active: activeTabIndex });
                    }
                },
                error: function() {
                    $panel.find('.q-el-slideout-body').html('<div style="padding: 20px; color: red;">Failed to load email content.</div>');
                }
            });
        }

        $(document).on('click', '.q-el-view-modal', function(event) {
            event.preventDefault();
            var ajaxUrl = $(this).data('url');
            var panelTitle = $(this).attr('title') || 'Email Content';
            openPanel(panelTitle, ajaxUrl);
        });

        // Close bindings
        $(document).on('click', '.q-el-slideout-close, #q-el-slideout-overlay', function(event) {
            event.preventDefault();
            closePanel();
        });

        $(document).on('click', '#thickbox-footer-close', function(event) {
            event.preventDefault();
            closePanel();
        });

        // Sent status tooltip
        if ($.isFunction($.fn.tooltip)) {
            $('.q-el-help').tooltip({
                content: function() { return $(this).prop('title'); },
                position: {
                    my: "center top",
                    at: "center bottom+10",
                    collision: "flipfit"
                },
                hide: { duration: 100 },
                show: { duration: 100 }
            });
        }
    });
})(jQuery);
