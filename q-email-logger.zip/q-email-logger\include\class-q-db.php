<?php namespace QEmailLog;

defined('ABSPATH') || exit; // Exit if accessed directly.

class QDB {

    const LOG_TABLE_NAME = 'q_email_log';
    const DB_VERSION_OPTION = 'q_email_log_db_version';
    const DB_VERSION = '1.0.0';

    /**
     * Get the log table name.
     */
    public static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . self::LOG_TABLE_NAME;
    }

    /**
     * Activate / Create table.
     */
    public static function activate() {
        global $wpdb;

        $table_name = self::get_table_name();
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            to_email VARCHAR(500) NOT NULL,
            subject VARCHAR(500) NOT NULL,
            message TEXT NOT NULL,
            headers TEXT NOT NULL,
            attachments TEXT NOT NULL,
            sent_date timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            attachment_name VARCHAR(1000),
            ip_address VARCHAR(100),
            result TINYINT(1) DEFAULT 1,
            error_message VARCHAR(1000),
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        add_option(self::DB_VERSION_OPTION, self::DB_VERSION);
    }

    /**
     * Update table if needed.
     */
    public static function update_table_if_needed() {
        $installed_version = get_option(self::DB_VERSION_OPTION);
        if ($installed_version !== self::DB_VERSION) {
            self::activate();
            update_option(self::DB_VERSION_OPTION, self::DB_VERSION);
        }
    }

    /**
     * Insert log item.
     */
    public function insert_log($data) {
        global $wpdb;
        $table_name = self::get_table_name();
        $wpdb->insert($table_name, $data);
    }

    /**
     * Delete log entries by ids.
     */
    public function delete_logs($ids) {
        global $wpdb;
        $table_name = self::get_table_name();
        $ids = esc_sql($ids);
        return $wpdb->query("DELETE FROM $table_name WHERE id IN ($ids)");
    }

    /**
     * Delete all log entries.
     */
    public function delete_all_logs() {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->query("DELETE FROM $table_name");
    }

    /**
     * Delete logs older than X days.
     */
    public function delete_logs_older_than($interval_in_days) {
        global $wpdb;
        $table_name = self::get_table_name();
        return $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE sent_date < DATE_SUB(CURDATE(), INTERVAL %d DAY)",
            $interval_in_days
        ));
    }

    /**
     * Get logs count.
     */
    public function get_logs_count() {
        global $wpdb;
        $table_name = self::get_table_name();
        return (int) $wpdb->get_var("SELECT count(*) FROM $table_name");
    }

    /**
     * Fetch log items by IDs.
     */
    public function fetch_log_items_by_id($ids = []) {
        global $wpdb;
        $table_name = self::get_table_name();

        if (empty($ids)) {
            return [];
        }

        $ids = array_map('absint', $ids);
        $ids_list = esc_sql(implode(',', $ids));

        $query = "SELECT * FROM $table_name WHERE id IN ($ids_list)";
        return $wpdb->get_results($query, 'ARRAY_A');
    }

    /**
     * Fetch log items with filtering, search, sorting, and pagination.
     */
    public function fetch_log_items($request, $per_page, $current_page_no) {
        global $wpdb;
        $table_name = self::get_table_name();

        $query       = "SELECT * FROM $table_name";
        $count_query = "SELECT count(*) FROM $table_name";
        $query_cond  = '';
        $where_clauses = [];

        // Handle Status Filter
        if (isset($request['status_filter']) && trim($request['status_filter']) !== '') {
            $status = trim(sanitize_text_field($request['status_filter']));
            if ($status === 'sent') {
                $where_clauses[] = "result = 1";
            } elseif ($status === 'failed') {
                $where_clauses[] = "result = 0";
            }
        }

        // Handle Recipient Tags (multi-tag email search)
        if (isset($request['recipient_tags']) && trim($request['recipient_tags']) !== '') {
            $recipients = explode(',', sanitize_text_field($request['recipient_tags']));
            $recipient_conds = [];
            foreach ($recipients as $recipient) {
                $recipient = trim(esc_sql($recipient));
                if (!empty($recipient)) {
                    $recipient_conds[] = "to_email LIKE '%$recipient%'";
                }
            }
            if (!empty($recipient_conds)) {
                $where_clauses[] = '(' . implode(' OR ', $recipient_conds) . ')';
            }
        }

        // Handle Subject Filter
        if (isset($request['subject_filter']) && trim($request['subject_filter']) !== '') {
            $subject = trim(esc_sql(sanitize_text_field($request['subject_filter'])));
            $where_clauses[] = "subject LIKE '%$subject%'";
        }

        // Handle Date Range (Start Date and End Date)
        if (isset($request['start_date']) && trim($request['start_date']) !== '') {
            $start_date = trim(esc_sql(sanitize_text_field($request['start_date'])));
            $where_clauses[] = "sent_date >= '$start_date 00:00:00'";
        }
        if (isset($request['end_date']) && trim($request['end_date']) !== '') {
            $end_date = trim(esc_sql(sanitize_text_field($request['end_date'])));
            $where_clauses[] = "sent_date <= '$end_date 23:59:59'";
        }

        if (!empty($where_clauses)) {
            $query_cond .= ' WHERE ' . implode(' AND ', $where_clauses);
        }

        // Sorting
        $order_by = 'sent_date';
        $order    = 'DESC';

        $allowed_order_by = ['sent_date', 'to_email', 'subject'];
        $sanitized_order_by = isset($request['orderby']) ? sanitize_text_field($request['orderby']) : '';
        if (in_array($sanitized_order_by, $allowed_order_by, true)) {
            $order_by = $sanitized_order_by;
        }

        if (isset($request['order']) && 'asc' === strtolower(sanitize_text_field($request['order']))) {
            $order = 'ASC';
        }

        $query_cond .= " ORDER BY $order_by $order";

        // Count Total Items
        $total_items = (int) $wpdb->get_var($count_query . $query_cond);

        // Limit & Pagination
        if (!empty($current_page_no) && !empty($per_page)) {
            $offset = ($current_page_no - 1) * $per_page;
            $query_cond .= $wpdb->prepare(" LIMIT %d, %d", $offset, $per_page);
        }

        // Fetch Items
        $items = $wpdb->get_results($query . $query_cond);

        return [$items, $total_items];
    }

    /**
     * Fetches the log ID by email details.
     */
    public function fetch_log_id_by_data($data) {
        if (empty($data) || !is_array($data)) {
            return 0;
        }

        global $wpdb;
        $table_name = self::get_table_name();

        $query = "SELECT id FROM $table_name";
        $where = [];

        if (isset($data['to'])) {
            $to_email = QHelper::stringify($data['to']);
            $to_email = trim(esc_sql($to_email));
            $where[]  = "to_email = '$to_email'";
        }

        if (isset($data['subject'])) {
            $subject = trim(esc_sql($data['subject']));
            $where[] = "subject = '$subject'";
        }

        $query_cond = '';
        foreach ($where as $index => $value) {
            $query_cond .= 0 === $index ? ' WHERE ' : ' AND ';
            $query_cond .= $value;
        }

        $query_cond .= ' ORDER BY id DESC LIMIT 1';

        return absint($wpdb->get_var($query . $query_cond));
    }

    /**
     * Mark log as failed.
     */
    public function mark_log_as_failed($log_item_id, $message) {
        global $wpdb;
        $table_name = self::get_table_name();

        $wpdb->update(
            $table_name,
            [
                'result'        => 0,
                'error_message' => $message,
            ],
            ['id' => $log_item_id],
            ['%d', '%s'],
            ['%d']
        );
    }

    /**
     * Mark log as succeeded.
     */
    public function mark_log_as_succeeded($log_item_id) {
        global $wpdb;
        $table_name = self::get_table_name();

        $wpdb->update(
            $table_name,
            [
                'result'        => 1,
                'error_message' => '',
            ],
            ['id' => $log_item_id],
            ['%d', '%s'],
            ['%d']
        );
    }

    /**
     * Search distinct recipients from logs.
     */
    public function search_recipients($term) {
        global $wpdb;
        $table_name = self::get_table_name();
        $term = trim(esc_sql($term));
        if (empty($term)) {
            return [];
        }
        $query = $wpdb->prepare(
            "SELECT DISTINCT to_email FROM $table_name WHERE to_email LIKE %s LIMIT 10",
            '%' . $wpdb->esc_like($term) . '%'
        );
        return $wpdb->get_col($query);
    }

    /**
     * Search distinct subjects from logs.
     */
    public function search_subjects($term) {
        global $wpdb;
        $table_name = self::get_table_name();
        $term = trim(esc_sql($term));
        if (empty($term)) {
            return [];
        }
        $query = $wpdb->prepare(
            "SELECT DISTINCT subject FROM $table_name WHERE subject LIKE %s LIMIT 10",
            '%' . $wpdb->esc_like($term) . '%'
        );
        return $wpdb->get_col($query);
    }
}
